<?php 

$conn= new mysqli('localhost','u230684563_root','DatabaseDam105+','u230684563_CameroVnet')or die("No se pudo conectar a mysql".mysqli_error($con));
